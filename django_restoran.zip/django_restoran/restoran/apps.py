from django.apps import AppConfig


class RestoranConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'restoran'
    verbose_name = 'Restoran'
