from django.db import models
from django.contrib.auth.models import User


class Kategoriya(models.Model):
    nomi = models.CharField(max_length=100)

    def __str__(self):
        return self.nomi

    class Meta:
        verbose_name = "Kategoriya"
        verbose_name_plural = "Kategoriyalar"


class Taom(models.Model):
    nomi = models.CharField(max_length=200)
    narxi = models.IntegerField()
    kategoriya = models.ForeignKey(Kategoriya, on_delete=models.CASCADE)
    emoji = models.CharField(max_length=10, default="🍽️")
    tayyorlanish_vaqti = models.CharField(max_length=20, default="20 min")
    tavsif = models.TextField(blank=True)
    mavjud = models.BooleanField(default=True)

    def __str__(self):
        return self.nomi

    class Meta:
        verbose_name = "Taom"
        verbose_name_plural = "Taomlar"


class Profil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    telefon = models.CharField(max_length=20, blank=True)
    manzil = models.CharField(max_length=300, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} profili"

    class Meta:
        verbose_name = "Profil"
        verbose_name_plural = "Profillar"


class Buyurtma(models.Model):
    HOLAT_CHOICES = [
        ('yangi', '🟡 Yangi'),
        ('tayyorlanmoqda', '🔵 Tayyorlanmoqda'),
        ('yetkazilmoqda', '🟠 Yetkazilmoqda'),
        ('yetkazildi', '🟢 Yetkazildi'),
        ('bekor', '🔴 Bekor qilindi'),
    ]
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    manzil = models.CharField(max_length=300)
    telefon = models.CharField(max_length=20)
    holat = models.CharField(max_length=20, choices=HOLAT_CHOICES, default='yangi')
    jami_narx = models.IntegerField(default=0)
    izoh = models.TextField(blank=True)
    yaratilgan = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Buyurtma #{self.pk}"

    class Meta:
        verbose_name = "Buyurtma"
        verbose_name_plural = "Buyurtmalar"
        ordering = ['-yaratilgan']


class BuyurtmaQatori(models.Model):
    buyurtma = models.ForeignKey(Buyurtma, on_delete=models.CASCADE, related_name='qatorlar')
    taom = models.ForeignKey(Taom, on_delete=models.CASCADE)
    miqdor = models.IntegerField(default=1)
    narxi = models.IntegerField()

    def jami(self):
        return self.miqdor * self.narxi

    def __str__(self):
        return f"{self.taom.nomi} x{self.miqdor}"
