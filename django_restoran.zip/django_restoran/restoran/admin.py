from django.contrib import admin
from .models import Taom, Kategoriya, Buyurtma, BuyurtmaQatori, Profil


@admin.register(Kategoriya)
class KategoriyaAdmin(admin.ModelAdmin):
    list_display = ['nomi']


@admin.register(Taom)
class TaomAdmin(admin.ModelAdmin):
    list_display = ['nomi', 'kategoriya', 'narxi', 'mavjud']
    list_filter = ['kategoriya', 'mavjud']
    search_fields = ['nomi']


class BuyurtmaQatoriInline(admin.TabularInline):
    model = BuyurtmaQatori
    extra = 0


@admin.register(Buyurtma)
class BuyurtmaAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'manzil', 'holat', 'jami_narx', 'yaratilgan']
    list_filter = ['holat']
    inlines = [BuyurtmaQatoriInline]


@admin.register(Profil)
class ProfilAdmin(admin.ModelAdmin):
    list_display = ['user', 'telefon', 'manzil']
