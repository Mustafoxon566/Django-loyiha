import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from .models import Taom, Kategoriya, Buyurtma, BuyurtmaQatori, Profil


# ===================== SAHIFALAR =====================

def index(request):
    taomlar_soni = Taom.objects.filter(mavjud=True).count()
    buyurtmalar_soni = Buyurtma.objects.count()
    foydalanuvchilar_soni = User.objects.count()
    return render(request, 'restoran/index.html', {
        'taomlar_soni': taomlar_soni,
        'buyurtmalar_soni': buyurtmalar_soni,
        'foydalanuvchilar_soni': foydalanuvchilar_soni,
    })


def menyu(request):
    kategoriyalar = Kategoriya.objects.all()
    return render(request, 'restoran/menyu.html', {'kategoriyalar': kategoriyalar})


def buyurtma_sahifa(request):
    return render(request, 'restoran/buyurtma.html')


@login_required
def profil(request):
    profil_obj, _ = Profil.objects.get_or_create(user=request.user)
    buyurtmalar = Buyurtma.objects.filter(user=request.user).order_by('-yaratilgan')[:10]
    return render(request, 'restoran/profil.html', {
        'profil': profil_obj,
        'buyurtmalar': buyurtmalar,
    })


def kirish_sahifa(request):
    if request.user.is_authenticated:
        return redirect('/')
    if request.method == 'POST':
        username = request.POST.get('username')
        parol = request.POST.get('parol')
        user = authenticate(request, username=username, password=parol)
        if user:
            login(request, user)
            return redirect('/')
        return render(request, 'restoran/kirish.html', {'xato': "Username yoki parol noto'g'ri!"})
    return render(request, 'restoran/kirish.html')


def royxat_sahifa(request):
    if request.user.is_authenticated:
        return redirect('/')
    if request.method == 'POST':
        ism = request.POST.get('ism', '').strip()
        familiya = request.POST.get('familiya', '').strip()
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        telefon = request.POST.get('telefon', '').strip()
        parol = request.POST.get('parol', '').strip()
        if User.objects.filter(username=username).exists():
            return render(request, 'restoran/royxat.html', {'xato': "Bu username band!"})
        user = User.objects.create_user(username=username, email=email, password=parol, first_name=ism, last_name=familiya)
        Profil.objects.create(user=user, telefon=telefon)
        login(request, user)
        return redirect('/')
    return render(request, 'restoran/royxat.html')


def chiqish(request):
    logout(request)
    return redirect('/')


# ===================== API (AJAX) =====================

def api_menyu(request):
    kategoriya_id = request.GET.get('kategoriya', '')
    taomlar = Taom.objects.filter(mavjud=True)
    if kategoriya_id:
        taomlar = taomlar.filter(kategoriya_id=kategoriya_id)
    data = [{
        'id': t.id,
        'nomi': t.nomi,
        'narxi': t.narxi,
        'emoji': t.emoji,
        'kategoriya': t.kategoriya.nomi,
        'vaqt': t.tayyorlanish_vaqti,
        'tavsif': t.tavsif,
    } for t in taomlar]
    return JsonResponse({'taomlar': data, 'jami': len(data)})


@require_POST
def api_buyurtma(request):
    try:
        data = json.loads(request.body)
        savatcha = data.get('savatcha', [])
        manzil = data.get('manzil', '')
        telefon = data.get('telefon', '')
        izoh = data.get('izoh', '')

        if not savatcha or not manzil or not telefon:
            return JsonResponse({'muvaffaqiyat': False, 'xabar': "Barcha maydonlarni to'ldiring!"})

        jami = sum(item['narxi'] * item['miqdor'] for item in savatcha)

        buyurtma = Buyurtma.objects.create(
            user=request.user if request.user.is_authenticated else None,
            manzil=manzil,
            telefon=telefon,
            izoh=izoh,
            jami_narx=jami + 10000,
        )

        for item in savatcha:
            taom = get_object_or_404(Taom, id=item['id'])
            BuyurtmaQatori.objects.create(
                buyurtma=buyurtma,
                taom=taom,
                miqdor=item['miqdor'],
                narxi=item['narxi'],
            )

        return JsonResponse({
            'muvaffaqiyat': True,
            'xabar': f"Buyurtma qabul qilindi! ID: #{buyurtma.pk}",
            'buyurtma_id': buyurtma.pk,
        })
    except Exception as e:
        return JsonResponse({'muvaffaqiyat': False, 'xabar': str(e)})


@login_required
@require_POST
def api_profil_yangilash(request):
    try:
        data = json.loads(request.body)
        user = request.user
        user.first_name = data.get('ism', user.first_name)
        user.last_name = data.get('familiya', user.last_name)
        user.save()
        profil_obj, _ = Profil.objects.get_or_create(user=user)
        profil_obj.telefon = data.get('telefon', profil_obj.telefon)
        profil_obj.manzil = data.get('manzil', profil_obj.manzil)
        profil_obj.save()
        return JsonResponse({'muvaffaqiyat': True, 'xabar': 'Profil yangilandi!'})
    except Exception as e:
        return JsonResponse({'muvaffaqiyat': False, 'xabar': str(e)})


def api_statistika(request):
    return JsonResponse({
        'foydalanuvchilar': User.objects.count(),
        'buyurtmalar': Buyurtma.objects.count(),
        'taomlar': Taom.objects.filter(mavjud=True).count(),
    })
