// Toast xabarnoma
function showToast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 10);
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 2800);
}

// Django messages avtomatik ko'rsatish
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.messages-container .toast').forEach(t => {
    setTimeout(() => t.classList.remove('show'), 3000);
  });
});
