from django.urls import path
from . import views

urlpatterns = [
    # Sahifalar
    path('', views.index, name='index'),
    path('menyu/', views.menyu, name='menyu'),
    path('buyurtma/', views.buyurtma_sahifa, name='buyurtma'),
    path('profil/', views.profil, name='profil'),
    path('kirish/', views.kirish_sahifa, name='kirish'),
    path('royxat/', views.royxat_sahifa, name='royxat'),
    path('chiqish/', views.chiqish, name='chiqish'),

    # API (AJAX)
    path('api/menyu/', views.api_menyu, name='api_menyu'),
    path('api/buyurtma/', views.api_buyurtma, name='api_buyurtma'),
    path('api/profil/yangilash/', views.api_profil_yangilash, name='api_profil_yangilash'),
    path('api/statistika/', views.api_statistika, name='api_statistika'),
]
