# 🍽️ Dasturxon — Django Restoran Loyihasi

## Texnologiyalar
- **Backend:** Python + Django 4.2
- **Frontend:** HTML, CSS, JavaScript (AJAX fetch API)
- **Ma'lumotlar bazasi:** SQLite (avtomatik)
- **Autentifikatsiya:** Django built-in auth

## Loyiha tuzilishi
```
django_restoran/
├── manage.py                  ← Loyihani boshqarish
├── requirements.txt           ← Kerakli kutubxonalar
├── db.sqlite3                 ← Ma'lumotlar bazasi (avtomatik)
├── config/
│   ├── settings.py            ← Django sozlamalari
│   └── urls.py                ← Asosiy URL yo'naltirish
└── restoran/                  ← Asosiy ilova
    ├── models.py              ← Ma'lumotlar modellari
    ├── views.py               ← Ko'rinishlar (sahifa + AJAX API)
    ├── urls.py                ← URL manzillar
    ├── admin.py               ← Admin panel
    ├── fixtures/menyu.json    ← Tayyor menyu ma'lumotlari
    ├── templates/restoran/    ← HTML shablonlar
    └── static/restoran/       ← CSS, JS fayllar
```

## Ishga tushirish (qadam-baqadam)

### 1. Django o'rnatish
```bash
pip install django
```

### 2. Migratsiyalarni bajarish
```bash
python manage.py migrate
```

### 3. Menyu ma'lumotlarini yuklash
```bash
python manage.py loaddata restoran/fixtures/menyu.json
```

### 4. Admin foydalanuvchi yaratish (ixtiyoriy)
```bash
python manage.py createsuperuser
```

### 5. Serverni ishga tushirish
```bash
python manage.py runserver
```

### 6. Brauzerda oching
- **Sayt:** http://127.0.0.1:8000
- **Admin panel:** http://127.0.0.1:8000/admin

---

## Sahifalar
| URL | Vazifasi |
|-----|----------|
| `/` | Bosh sahifa |
| `/menyu/` | Menyu (AJAX filtrlash) |
| `/buyurtma/` | Savatcha va buyurtma |
| `/profil/` | Foydalanuvchi profili |
| `/kirish/` | Kirish sahifasi |
| `/royxat/` | Ro'yxatdan o'tish |
| `/admin/` | Admin panel |

## API Endpointlar (AJAX)
| URL | Method | Vazifasi |
|-----|--------|----------|
| `/api/menyu/` | GET | Taomlar ro'yxati (filtrlash mumkin) |
| `/api/buyurtma/` | POST | Yangi buyurtma berish |
| `/api/profil/yangilash/` | POST | Profilni yangilash |
| `/api/statistika/` | GET | Umumiy statistika |
